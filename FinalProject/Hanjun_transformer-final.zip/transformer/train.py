import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import os
from datetime import timedelta
import math
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

def positional_encoding(seq_len, d_model, device):
    pe = torch.zeros(seq_len, d_model, device=device)
    position = torch.arange(0, seq_len, dtype=torch.float32,
                            device=device).unsqueeze(1)
    div_term = torch.exp(torch.arange(0, d_model, 2, device=device) *
                         (-math.log(10000.0) / d_model))
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    return pe

def create_sequences(df, window_size=7):
    target_power_cols = [c for c in df.columns if c.startswith('Power') and not c.endswith('_lag1')]
    
    current_power_cols = target_power_cols
    lag_power_cols = [c for c in df.columns if c.startswith('Power') and c.endswith('_lag1')]
    
    other_engineered_features = ['DayOfWeek', 'Month', 'Season', 'IsWeekend',
                                 'AvgPower', 'MaxPower', 'MinPower', 'StdPower']
    available_other_features = [col for col in other_engineered_features if col in df.columns]

    feat_cols = current_power_cols + lag_power_cols + available_other_features
    
    missing_cols = [col for col in feat_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Columns missing in DataFrame for sequence creation: {missing_cols}")

    X, y = [], []
    for i in range(len(df) - window_size):
        seq = df.iloc[i:i+window_size][feat_cols].values
        tgt = df.iloc[i+window_size][target_power_cols].values
        X.append(seq)
        y.append(tgt)
    
    X_np = np.array(X, dtype=np.float32)
    y_np = np.array(y, dtype=np.float32)

    if np.isnan(X_np).any():
        print("Warning: NaNs found in X after create_sequences. Check NaN handling in preprocess_data.")
    if np.isnan(y_np).any():
        print("Warning: NaNs found in y after create_sequences. Check NaN handling for target columns.")
        
    return X_np, y_np

def evaluate_model(y_true, y_pred):
    from sklearn.metrics import mean_squared_error, mean_absolute_error
    
    rmse = np.sqrt(mean_squared_error(y_true.flatten(), y_pred.flatten()))
    mae = mean_absolute_error(y_true.flatten(), y_pred.flatten())
    
    mask = y_true.flatten() != 0
    y_true_safe = y_true.flatten()[mask]
    y_pred_safe = y_pred.flatten()[mask]
    
    if len(y_true_safe) > 0:
        non_zero_mask_for_mape = y_true_safe != 0
        if np.any(non_zero_mask_for_mape):
             mape = np.mean(np.abs((y_true_safe[non_zero_mask_for_mape] - y_pred_safe[non_zero_mask_for_mape]) / y_true_safe[non_zero_mask_for_mape])) * 100
        else:
            mape = np.nan
    else:
        mape = np.nan
    
    return {
        'RMSE': rmse,
        'MAE': mae,
        'MAPE': mape
    }

def preprocess_data(data):
    df = data.copy()
    
    if not pd.api.types.is_datetime64_any_dtype(df['Date']):
        df['Date'] = pd.to_datetime(df['Date'])
    
    original_power_cols = [col for col in df.columns if col.startswith('Power') and not col.endswith('_lag1')]
    
    lag_power_cols = []
    if not original_power_cols and 'Power' in ''.join(df.columns): 
        print("Warning: No columns starting with 'Power' and not ending with '_lag1' found. Lag features might not be created correctly.")

    for col in original_power_cols:
        lag_col_name = f'{col}_lag1'
        df[lag_col_name] = df[col].shift(1)
        lag_power_cols.append(lag_col_name)
        
    all_power_related_cols = original_power_cols + lag_power_cols
    for col in all_power_related_cols:
        if col in df: 
            df[col] = df[col].interpolate(method='linear')
            df[col] = df[col].bfill().ffill() 
            if df[col].isnull().any():
                 df[col] = df[col].fillna(0)

    date_features = pd.DataFrame({
        'DayOfWeek': df['Date'].dt.dayofweek,
        'Month': df['Date'].dt.month,
        'Season': (df['Date'].dt.month % 12 + 3) // 3,
        'IsWeekend': df['Date'].dt.dayofweek.apply(lambda x: 1 if x >= 5 else 0)
    }, index=df.index) 
    
    power_df_for_stats = df[original_power_cols]
    stat_features = pd.DataFrame({
        'AvgPower': power_df_for_stats.mean(axis=1),
        'MaxPower': power_df_for_stats.max(axis=1),
        'MinPower': power_df_for_stats.min(axis=1),
        'StdPower': power_df_for_stats.std(axis=1).fillna(0)
    }, index=df.index) 
    
    df = pd.concat([df, date_features, stat_features], axis=1)
    
    return df

class PowerTransformer(nn.Module):
    def __init__(self, input_dim, d_model, nhead,
                 num_layers, output_dim, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.input_proj = nn.Linear(input_dim, d_model)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, batch_first=True,
            dim_feedforward=4*d_model, dropout=dropout, activation='gelu')
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers)
        self.regressor = nn.Linear(d_model, output_dim)

    def forward(self, x):
        B, S, _ = x.size()
        x = self.input_proj(x)
        x = x + positional_encoding(S, self.d_model, x.device)
        h = self.encoder(x)
        out = self.regressor(h[:, -1, :])
        return out
    
def transformer(window_size=7, epochs=60, batch_size=128,
                d_model=64, nhead=8, n_layers=3, lr=1e-3):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    base_path = '/home/astar/workspace/CS412/final/transformer/' 
    model_dir = os.path.join(base_path, 'transformer') 
    data_dir = os.path.join(base_path, 'data')
    os.makedirs(model_dir, exist_ok=True)

    train_data_pd = pd.read_excel(os.path.join(data_dir, 'train_data.xlsx'))
    val_data_pd = pd.read_excel(os.path.join(data_dir, 'validation_data.xlsx'))
    check_data_pd = pd.read_excel(os.path.join(data_dir, 'check_data_to_students.xlsx'))

    train_df = preprocess_data(train_data_pd)
    val_df   = preprocess_data(val_data_pd)
    check_df = preprocess_data(check_data_pd)

    p_cols = [c for c in train_df.columns if c.startswith('Power') and not c.endswith('_lag1')]
    if not p_cols:
        raise ValueError("No target power columns (p_cols) found in training data after preprocessing. Check column names and preprocess_data.")
        
    lag_p_cols = [f'{c}_lag1' for c in p_cols if f'{c}_lag1' in train_df.columns]

    scaler = MinMaxScaler()
    
    missing_p_cols_train = [col for col in p_cols if col not in train_df.columns]
    if missing_p_cols_train:
        raise ValueError(f"Target power columns {missing_p_cols_train} not found in train_df before scaling.")
    train_df[p_cols] = scaler.fit_transform(train_df[p_cols].values)
    
    missing_p_cols_val = [col for col in p_cols if col not in val_df.columns]
    if missing_p_cols_val:
        raise ValueError(f"Target power columns {missing_p_cols_val} not found in val_df before scaling.")
    val_df[p_cols]   = scaler.transform(val_df[p_cols].values)

    if lag_p_cols:
        missing_lag_cols_train = [col for col in lag_p_cols if col not in train_df.columns]
        if missing_lag_cols_train:
             raise ValueError(f"Lag power columns {missing_lag_cols_train} not found in train_df before scaling.")
        train_df[lag_p_cols] = scaler.transform(train_df[lag_p_cols].values)
        
        missing_lag_cols_val = [col for col in lag_p_cols if col not in val_df.columns]
        if missing_lag_cols_val:
             raise ValueError(f"Lag power columns {missing_lag_cols_val} not found in val_df before scaling.")
        val_df[lag_p_cols]   = scaler.transform(val_df[lag_p_cols].values)

    X_train, y_train = create_sequences(train_df, window_size)
    X_val,   y_val   = create_sequences(val_df,   window_size)

    if X_train.size == 0 or X_val.size == 0:
        raise ValueError("Not enough data to create sequences after processing. Check window_size and data length, and NaN handling.")

    ds_tr = TensorDataset(torch.tensor(X_train), torch.tensor(y_train))
    ds_va = TensorDataset(torch.tensor(X_val),   torch.tensor(y_val))
    dl_tr = DataLoader(ds_tr, batch_size=batch_size, shuffle=True)
    dl_va = DataLoader(ds_va, batch_size=batch_size, shuffle=False)

    model = PowerTransformer(input_dim=X_train.shape[-1],
                             d_model=d_model, nhead=nhead,
                             num_layers=n_layers,
                             output_dim=y_train.shape[1]).to(device)
    opt   = torch.optim.AdamW(model.parameters(), lr=lr)
    crit = nn.MSELoss()

    best_rmse, patience, wait = float('inf'), 10, 0 
    model_save_path = os.path.join(model_dir, 'transformer_lag.pth')
    
    # Variables to store best epoch's validation results for plotting
    y_true_res_best_epoch = None
    y_pred_res_best_epoch = None


    for ep in range(1, epochs+1):
        model.train()
        for xb, yb in dl_tr:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            pred = model(xb)
            loss = crit(pred, yb)
            loss.backward()
            opt.step()

        model.eval()
        preds_val_list, gts_val_list = [], []
        with torch.no_grad():
            for xb_val, yb_val in dl_va:
                xb_val = xb_val.to(device)
                preds_val_list.append(model(xb_val).cpu())
                gts_val_list.append(yb_val)
        y_pred_val = torch.cat(preds_val_list).numpy()
        y_true_val = torch.cat(gts_val_list).numpy()

        # Inverse transform for metric calculation and potential saving for plots
        current_y_pred_res = scaler.inverse_transform(y_pred_val)
        current_y_true_res = scaler.inverse_transform(y_true_val)
        
        metrics = evaluate_model(current_y_true_res, current_y_pred_res)
        rmse_val = metrics['RMSE'] 
        mae_val = metrics['MAE']   
        mape_val = metrics['MAPE'] 
        
        mape_str = f"{mape_val:.4f}%" if not np.isnan(mape_val) else "N/A"
        print(f'Epoch {ep:2d}: RMSE={rmse_val:.4f}  MAE={mae_val:.4f}  MAPE={mape_str}')

        if rmse_val < best_rmse:
            best_rmse, wait = rmse_val, 0
            torch.save(model.state_dict(), model_save_path)
            # Save results from the best epoch for plotting
            y_true_res_best_epoch = current_y_true_res
            y_pred_res_best_epoch = current_y_pred_res
            print(f"New best model saved with RMSE: {best_rmse:.4f}")
        else:
            wait += 1
            if wait >= patience:
                print('Early stopping')
                break
    
    # Use results from the best epoch for plotting if early stopping happened,
    # otherwise use results from the last epoch (if y_true_res_best_epoch is None but training finished)
    final_y_true_res = y_true_res_best_epoch if y_true_res_best_epoch is not None else current_y_true_res
    final_y_pred_res = y_pred_res_best_epoch if y_pred_res_best_epoch is not None else current_y_pred_res


    if final_y_true_res is not None and final_y_pred_res is not None and final_y_true_res.size > 0 and final_y_pred_res.size > 0:
        # Overall plot
        plt.figure(figsize=(20, 10))
        y_true_flat = final_y_true_res.flatten()
        y_pred_flat = final_y_pred_res.flatten()
        plt.plot(y_true_flat, label='Actual (Validation - All Samples Concatenated)')
        plt.plot(y_pred_flat, label='Predicted (Validation - All Samples Concatenated)', alpha=0.7)
        plt.title('Transformer Validation - Overall Performance (with Lag Feature)')
        plt.xlabel('Time point (Concatenated 15-minute intervals from validation set)')
        plt.ylabel('Power')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(model_dir, 'transformer_validation_overall_lag.png'))
        # plt.show()

        # Best performing day plot
        if final_y_true_res.ndim == 2 and final_y_pred_res.ndim == 2 and final_y_true_res.shape == final_y_pred_res.shape and final_y_true_res.shape[0] > 0:
            daily_rmses = [np.sqrt(np.mean((final_y_true_res[i] - final_y_pred_res[i])**2)) for i in range(final_y_true_res.shape[0])]
            if daily_rmses:
                best_day_idx = np.argmin(daily_rmses)
                min_rmse_for_day = daily_rmses[best_day_idx]

                plt.figure(figsize=(18, 7)) 
                plt.plot(final_y_true_res[best_day_idx, :], label=f'Actual (Best Day - Idx {best_day_idx})', marker='.', linestyle='-')
                plt.plot(final_y_pred_res[best_day_idx, :], label=f'Predicted (Best Day - Idx {best_day_idx})', marker='.', linestyle='--')
                plt.title(f'Transformer Validation - Detailed Plot for Best RMSE Day (Idx: {best_day_idx}, Day RMSE: {min_rmse_for_day:.4f})')
                plt.xlabel(f'Time point within day (e.g., 0-{final_y_true_res.shape[1]-1})')
                plt.ylabel('Power')
                plt.legend()
                plt.grid(True)
                plt.tight_layout()
                plt.savefig(os.path.join(model_dir, 'transformer_validation_best_day_detail.png'))
                # plt.show() 
            else:
                print("Could not calculate daily RMSEs for plotting best day.")
        else:
            print("Validation results (final_y_true_res, final_y_pred_res) not suitable for best day plot (e.g., not 2D or empty).")
    else:
        print("Validation results not available for plotting.")


    print('Generating predictions for check set...')
    if os.path.exists(model_save_path):
        # Load the best model for check set prediction
        model.load_state_dict(torch.load(model_save_path, map_location=device))
        print(f"Loaded best model from {model_save_path} for check set prediction.")
    else:
        print(f"Warning: Model file not found at {model_save_path}. Predictions will be based on the last state of the model (if training completed).")
    model.eval()

    preds_check_output_df = pd.DataFrame()
    if 'Date' not in check_df.columns: 
        raise ValueError("The 'Date' column is missing from the check_data after preprocessing.")
        
    check_scaled_df = check_df.copy() 
    
    missing_p_cols_check = [col for col in p_cols if col not in check_scaled_df.columns]
    if missing_p_cols_check:
        raise ValueError(f"Target power columns {missing_p_cols_check} not found in check_scaled_df before scaling.")
    check_scaled_df[p_cols] = scaler.transform(check_scaled_df[p_cols].values)

    if lag_p_cols: 
        missing_lag_cols_check = [col for col in lag_p_cols if col not in check_scaled_df.columns]
        if missing_lag_cols_check:
            raise ValueError(f"Lag columns {missing_lag_cols_check} are missing from preprocessed check_data. Cannot scale.")
        check_scaled_df[lag_p_cols] = scaler.transform(check_scaled_df[lag_p_cols].values)

    _target_power_cols_train = [c for c in train_df.columns if c.startswith('Power') and not c.endswith('_lag1')]
    _lag_power_cols_train = [c for c in train_df.columns if c.startswith('Power') and c.endswith('_lag1')]
    _other_engineered_features_train = ['DayOfWeek', 'Month', 'Season', 'IsWeekend',
                                     'AvgPower', 'MaxPower', 'MinPower', 'StdPower']
    _available_other_features_train = [col for col in _other_engineered_features_train if col in train_df.columns] 
    
    master_feat_cols = _target_power_cols_train + _lag_power_cols_train + _available_other_features_train
    
    missing_master_cols_in_check = [col for col in master_feat_cols if col not in check_scaled_df.columns]
    if missing_master_cols_in_check:
        raise ValueError(f"Essential feature columns {missing_master_cols_in_check} for model prediction are missing from preprocessed and scaled check_data.")


    if len(check_scaled_df) < window_size:
        print(f"Warning: Check data length ({len(check_scaled_df)}) is less than window size ({window_size}). Cannot generate predictions.")
    else:
        input_sequences_check_list = []
        dates_for_prediction_check_list = []

        for i in range(len(check_scaled_df) - window_size):
            seq_check_array = check_scaled_df.iloc[i : i + window_size][master_feat_cols].values.astype(np.float32)
            if np.isnan(seq_check_array).any():
                print(f"Warning: NaN found in sequence for check_data at index {i}. Skipping this sequence.")
                continue 
            input_sequences_check_list.append(seq_check_array)
            dates_for_prediction_check_list.append(check_scaled_df.iloc[i + window_size]['Date'])
        
        if input_sequences_check_list:
            input_sequences_check_tensor = torch.tensor(np.array(input_sequences_check_list)).to(device)
            
            all_preds_scaled_check_list = []
            check_ds = TensorDataset(input_sequences_check_tensor) 
            check_dl = DataLoader(check_ds, batch_size=batch_size, shuffle=False)

            with torch.no_grad():
                for batch_data_check in check_dl: 
                    batch_seq_check_tensor = batch_data_check[0] 
                    pred_batch_scaled_array = model(batch_seq_check_tensor).cpu().numpy()
                    all_preds_scaled_check_list.append(pred_batch_scaled_array)
            
            if all_preds_scaled_check_list:
                final_preds_scaled_check_array = np.concatenate(all_preds_scaled_check_list, axis=0)
                final_preds_inversed_check_array = scaler.inverse_transform(final_preds_scaled_check_array)
                
                pred_df_list = []
                for idx, date_val in enumerate(dates_for_prediction_check_list):
                    pred_single_day_df = pd.DataFrame([final_preds_inversed_check_array[idx]], columns=p_cols)
                    pred_single_day_df['Date'] = date_val
                    pred_df_list.append(pred_single_day_df)
                
                if pred_df_list:
                    preds_check_output_df = pd.concat(pred_df_list, ignore_index=True)
                    cols_order = ['Date'] + p_cols
                    preds_check_output_df = preds_check_output_df[cols_order]
                    preds_check_output_df = preds_check_output_df.sort_values(by='Date').reset_index(drop=True)
                    preds_check_output_df.to_csv(os.path.join(model_dir, 'check_predictions_trans_lag.csv'), index=False)
                else:
                    print("No predictions were generated for the check set after processing (pred_df_list empty).")
            else:
                print("Model did not return any scaled predictions for the check set (all_preds_scaled_check_list empty).")
        else:
            print("Not enough data in check set to form any input sequences for prediction (input_sequences_check_list empty).")

    if not preds_check_output_df.empty:
        print(f"Predictions for check set saved to {os.path.join(model_dir, 'check_predictions_trans_lag.csv')}")
    else:
        print("No predictions were generated or saved for the check set.")
        
    print('Transformer (with lag feature) 训练与预测完成！')

if __name__ == "__main__":
    transformer()