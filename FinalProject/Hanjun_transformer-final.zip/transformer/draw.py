import matplotlib.pyplot as plt

# 提取 epoch、RMSE、MAE 数据
epochs = list(range(1, 60))
rmse_values = [
    1.2566, 0.9865, 0.9686, 0.9898, 0.9557, 0.9212, 0.9127, 0.9118, 0.8927, 0.8856,
    0.8796, 0.8731, 0.8621, 0.8457, 0.8624, 0.8247, 0.8194, 0.8112, 0.8019, 0.8107,
    0.8168, 0.7970, 0.7839, 0.7945, 0.7971, 0.7812, 0.7823, 0.7838, 0.7705, 0.7465,
    0.7368, 0.7255, 0.7223, 0.7300, 0.7287, 0.7038, 0.6899, 0.6827, 0.6960, 0.6906,
    0.6659, 0.6618, 0.6600, 0.6637, 0.6593, 0.6555, 0.6627, 0.6498, 0.6462, 0.6399,
    0.6533, 0.6729, 0.6398, 0.6376, 0.6539, 0.6522, 0.6406, 0.6400, 0.6357
]

mae_values = [
    0.9703, 0.7736, 0.7553, 0.7698, 0.7459, 0.7215, 0.7157, 0.7129, 0.6966, 0.6877,
    0.6789, 0.6681, 0.6554, 0.6391, 0.6468, 0.6170, 0.6082, 0.6005, 0.5928, 0.5938,
    0.5967, 0.5848, 0.5768, 0.5793, 0.5791, 0.5700, 0.5691, 0.5692, 0.5582, 0.5423,
    0.5376, 0.5307, 0.5299, 0.5326, 0.5373, 0.5182, 0.5088, 0.5024, 0.5083, 0.5032,
    0.4895, 0.4852, 0.4832, 0.4862, 0.4816, 0.4789, 0.4854, 0.4753, 0.4727, 0.4706,
    0.4762, 0.4898, 0.4674, 0.4663, 0.4820, 0.4767, 0.4646, 0.4696, 0.4654
]

# 创建图表
fig, ax1 = plt.subplots(figsize=(12, 6))

color_rmse = 'tab:blue'
ax1.set_xlabel('Epoch')
ax1.set_ylabel('RMSE', color=color_rmse)
ax1.plot(epochs, rmse_values, label='RMSE', color=color_rmse, marker='o', linestyle='-', markersize=3)
ax1.tick_params(axis='y', labelcolor=color_rmse)

# 创建共享x轴的第二个y轴
ax2 = ax1.twinx()
color_mae = 'tab:orange'
ax2.set_ylabel('MAE', color=color_mae)
ax2.plot(epochs, mae_values, label='MAE', color=color_mae, marker='s', linestyle='--', markersize=3)
ax2.tick_params(axis='y', labelcolor=color_mae)

# 添加标题和图例
plt.title('Training RMSE and MAE over Epochs')
fig.tight_layout()

# 显示网格
ax1.grid(True, linestyle='--', alpha=0.5)

# 显示图像
plt.show()